import React from "react";
import MachineControl from "./components/MachineControl";


export default function App() {
  return <MachineControl />;
}
