// vite.config.ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'

const LogRequests = {
  name: 'log-requests',
  configureServer(server) {
    server.middlewares.use((req, _res, next) => {
      try {
        // Log the raw, undecoded URL:
        console.log('[REQ]', req.url)
      } catch {}
      next()
    })
  }
}

export default defineConfig({
  server: {
    // optional: hide red overlay while debugging
    hmr: { overlay: false },
    // optional: proxy APIs so Vite doesn't try to serve them
    proxy: {
      '/status': 'http://localhost:8000',
      '/api': 'http://localhost:8000',
    }
  },
  plugins: [
    LogRequests,       // 👈 FIRST
    react(),
    // TEMP: disable PWA plugin in dev to avoid SW interference
    VitePWA({
      registerType: 'autoUpdate',
      devOptions: { enabled: false },   // no SW in dev
      // (keep your manifest config here)
    })
  ]
})
