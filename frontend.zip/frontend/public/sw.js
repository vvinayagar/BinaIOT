/* Simple app-shell SW for CRA */
const CACHE_NAME = 'binaiot-app-shell-v1';
const CORE_ASSETS = [
  '/',                // served as SPA index
  '/index.html',
  '/manifest.webmanifest',
  '/favicon.ico'
];

// Install: pre-cache app shell
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(CORE_ASSETS))
  );
  self.skipWaiting();
});

// Activate: cleanup old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.map((k) => (k !== CACHE_NAME ? caches.delete(k) : null)))
    )
  );
  self.clients.claim();
});

// Fetch strategy:
// - navigation requests -> return cached index.html (SPA fallback)
// - same-origin static files -> Cache First
// - /api/* -> Network First (so your Django API stays fresh)
self.addEventListener('fetch', (event) => {
  const { request } = event;

  // Handle SPA navigations
  if (request.mode === 'navigate') {
    event.respondWith(
      caches.match('/index.html').then((resp) => resp || fetch('/index.html'))
    );
    return;
  }

  const url = new URL(request.url);

  // API: match 192.168.100.59, localhost, and 127.0.0.1
  if (/^https?:\/\/(192\.168\.100\.59|localhost|127\.0\.0\.1):8000\/.*/.test(request.url)) {
    event.respondWith(
      fetch(request)
        .then((networkResp) => {
          const copy = networkResp.clone();
          caches.open('api-cache').then((c) => c.put(request, copy));
          return networkResp;
        })
        .catch(() => caches.match(request))
    );
    return;
  }

  // Same-origin static -> Cache First
  if (url.origin === self.location.origin) {
    event.respondWith(
      caches.match(request).then((cached) => cached || fetch(request))
    );
  }
});
